# ❤️ Heart Disease Prediction — Orange Data Mining

A no-code machine learning workflow built in [Orange Data Mining](https://orangedatamining.com/) to explore and predict the presence of heart disease from clinical patient data.

![Orange](https://img.shields.io/badge/tool-Orange%20Data%20Mining-orange)
![Dataset](https://img.shields.io/badge/dataset-heart.csv-blue)
![Best AUC](https://img.shields.io/badge/best%20AUC-0.986%20(Tree)-brightgreen)
![Status](https://img.shields.io/badge/status-complete-success)

---

## 📌 Project Overview

This project uses the classic **Heart Disease dataset** (1,025 patient records, 13 clinical features) to explore which factors are most associated with heart disease and to compare four classification models — **Tree, Naive Bayes, Logistic Regression, and kNN** — all built visually in Orange's node-based canvas, no code required.

## 📊 Dataset

`data/heart.csv` — 1,025 rows × 14 columns.

| # | Column | Description |
|---|--------|-------------|
| 1 | `age` | Age in years |
| 2 | `sex` | 1 = male, 0 = female |
| 3 | `cp` | Chest pain type (4 values) |
| 4 | `trestbps` | Resting blood pressure |
| 5 | `chol` | Serum cholesterol (mg/dl) |
| 6 | `fbs` | Fasting blood sugar > 120 mg/dl (1 = true) |
| 7 | `restecg` | Resting ECG results (0, 1, 2) |
| 8 | `thalach` | Maximum heart rate achieved |
| 9 | `exang` | Exercise-induced angina (1 = yes) |
| 10 | `oldpeak` | ST depression induced by exercise relative to rest |
| 11 | `slope` | Slope of the peak exercise ST segment |
| 12 | `ca` | Number of major vessels (0–3) colored by fluoroscopy |
| 13 | `thal` | 0 = normal, 1 = fixed defect, 2 = reversible defect |
| 14 | `target` | 1 = heart disease present, 0 = absent |

No missing values in any of the 1,025 instances.

## 🧰 Tools Used

- [Orange Data Mining](https://orangedatamining.com/) 3.x
- Widgets: `CSV File Import`, `Data Table`, `Edit Domain`, `Column Statistics`, `Distributions`, `Box Plot`, `Scatter Plot`, `Correlations`, `Select Columns`, `Tree`, `Naive Bayes`, `Logistic Regression`, `kNN`, `Test and Score`, `Confusion Matrix`, `ROC Analysis`, `Tree Viewer`

## 🗺️ Workflow Diagram

![Canvas Overview](screenshots/canvas_overview.png)

```
                              ┌─→ Data Table
CSV File Import ──────────────┤
                              └─→ Edit Domain ──┬─→ Column Statistics
                                                ├─→ Distributions
                                                ├─→ Box Plot
                                                └─→ Scatter Plot
                                                └─→ Correlations

                                          ┌─→ Tree ──────────────┐
Edit Domain → Select Columns ────────────┼─→ Naive Bayes         │
                                          ├─→ Logistic Regression ┼─→ Test and Score → Confusion Matrix
                                          └─→ kNN ────────────────┘              └─→ ROC Analysis

Tree → Tree Viewer
```

## 🔬 Methodology

**1. Data Loading & Preparation**
- Loaded `heart.csv` via **CSV File Import** (1,025 instances, 14 features, no missing data).
- Used **Edit Domain** to re-type `cp`, `restecg`, `slope`, `ca`, and `thal` as **categorical** rather than numeric, since they represent coded categories, not true continuous measurements.

**2. Exploratory Data Analysis**
- **Column Statistics**: summary stats for every feature (mean, mode, median, dispersion, range).
- **Distributions**: histograms per feature.
- **Box Plot**: spread of numeric features (e.g. patient age).
- **Scatter Plot**: relationships between features, e.g. age vs. sex colored/shaped by other attributes.
- **Correlations (Pearson)**: ranked pairwise linear relationships between numeric features.

**3. Modeling & Evaluation**
- Trained four classifiers — **Tree**, **Naive Bayes**, **Logistic Regression**, **kNN** — via **Select Columns → [model]**.
- Compared performance with **Test and Score** (5-fold stratified cross-validation).
- Visualized true/false positive trade-offs with **ROC Analysis**.
- Inspected errors for the top model with **Confusion Matrix**.
- Interpreted the Tree model's actual decision logic with **Tree Viewer**.

## 📈 Results

**5-fold stratified cross-validation:**

| Model | AUC | CA (Accuracy) | F1 | Precision | Recall | MCC |
|-------|-----|------|------|-----------|--------|-----|
| 🥇 **Tree** | **0.986** | **0.957** | **0.957** | **0.957** | **0.957** | **0.914** |
| Logistic Regression | 0.937 | 0.866 | 0.866 | 0.866 | 0.866 | 0.733 |
| Naive Bayes | 0.919 | 0.846 | 0.846 | 0.846 | 0.846 | 0.691 |
| kNN | 0.864 | 0.726 | 0.726 | 0.727 | 0.726 | 0.452 |

![Test and Score](screenshots/test_and_score.png)

**Tree vs. other models — probability that Tree scores higher (pairwise comparison):**
Tree beat every other model with near-certainty (P ≥ 0.994 against Naive Bayes and kNN, P = 0.996 against Logistic Regression), confirming it isn't just a marginal winner.

### Confusion Matrix — Tree (on full data)

| | Predicted: No Disease (0) | Predicted: Disease (1) | Total |
|---|---|---|---|
| **Actual: No Disease (0)** | 481 | 18 | 499 |
| **Actual: Disease (1)** | 26 | 500 | 526 |
| **Total** | 507 | 518 | 1025 |

![Confusion Matrix](screenshots/confusion_matrix_tree.png)

Only 44 misclassifications out of 1,025 (18 false positives, 26 false negatives) — a strong result for a single decision tree.

### ROC Analysis

![ROC Analysis](screenshots/roc_analysis.png)

The Tree's ROC curve sits closest to the top-left corner (best), consistent with its top AUC of 0.986.

### Feature Correlations (Pearson, top pairs)

| Rank | Features | Correlation |
|------|----------|-------------|
| 1 | `age` : `thalach` | −0.390 |
| 2 | `oldpeak` : `thalach` | −0.350 |
| 3 | `age` : `trestbps` | +0.271 |
| 4 | `age` : `chol` | +0.220 |
| 5 | `age` : `oldpeak` | +0.208 |
| 6 | `oldpeak` : `trestbps` | +0.187 |
| 7 | `chol` : `trestbps` | +0.128 |
| 8 | `chol` : `oldpeak` | +0.065 |
| 9 | `thalach` : `trestbps` | −0.039 |
| 10 | `chol` : `thalach` | −0.022 |

![Correlations](screenshots/correlations.png)

The strongest relationship is that **older patients tend to have a lower maximum heart rate** (`age`:`thalach`, r = −0.39) — a well-known physiological pattern. No pair of numeric features is strongly correlated (all |r| < 0.4), so multicollinearity isn't a major concern for the linear model.

### Decision Tree structure

![Tree Viewer](screenshots/tree_viewer.png)

The tree's very first split is on **`cp`** (chest pain type), followed immediately by **`thal`** and **`ca`** — these three are the dominant predictors of heart disease in this model, consistent with their clinical significance (vessel blockage and chest pain type are core diagnostic signals).

### Age distribution

Patients average **54.4 ± 9.1 years old** (median 56, IQR 48–61).

![Box Plot](screenshots/box_plot_age.png)

## 🖼️ Full Screenshot Gallery

| | |
|---|---|
| Canvas overview | `screenshots/canvas_overview.png` |
| Data Table | `screenshots/data_table.png` |
| Column Statistics | `screenshots/column_statistics.png` |
| Edit Domain | `screenshots/edit_domain.png` |
| Distributions (age) | `screenshots/distributions_age.png` |
| Box Plot (age) | `screenshots/box_plot_age.png` |
| Scatter Plot | `screenshots/scatter_plot.png` |
| Correlations | `screenshots/correlations.png` |
| Test and Score | `screenshots/test_and_score.png` |
| ROC Analysis | `screenshots/roc_analysis.png` |
| Tree Viewer | `screenshots/tree_viewer.png` |
| Confusion Matrix (Tree) | `screenshots/confusion_matrix_tree.png` |

## 📁 Repository Structure

```
heart-disease-orange/
├── data/
│   └── heart.csv
├── workflow/
│   └── heart_disease.ows        # Orange workflow file (File → Save As in Orange)
├── screenshots/
│   └── *.png                    # 12 screenshots documenting the full pipeline
├── README.md
└── LICENSE
```

## ▶️ How to Reproduce

1. Install [Orange Data Mining](https://orangedatamining.com/download/) (free).
2. Clone this repo:
   ```bash
   git clone https://github.com/<your-username>/heart-disease-orange.git
   ```
3. Open Orange → **File → Open** → select `workflow/heart_disease.ows`.
4. Run the canvas — all widgets will re-execute on `data/heart.csv`.

## 🔑 Key Takeaways

- **`cp` (chest pain type), `thal`, and `ca`** are the strongest predictors of heart disease — they form the top splits in the decision tree.
- The **Tree model outperformed every other classifier** (AUC 0.986 vs. 0.937 for Logistic Regression, 0.919 for Naive Bayes, and 0.864 for kNN), with the win confirmed as statistically robust by the pairwise comparison table.
- **Age is inversely related to max heart rate** (r = −0.39) — the single strongest pairwise correlation in the dataset, and clinically expected.
- No numeric features show strong multicollinearity, so simpler linear models like Logistic Regression remain reliable and interpretable as a second opinion alongside the Tree.

## 📜 License

MIT License — feel free to reuse and adapt.

---

*Built as a hands-on exercise in visual, no-code machine learning with Orange Data Mining.*
